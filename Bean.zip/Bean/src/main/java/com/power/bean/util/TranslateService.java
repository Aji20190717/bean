package com.power.bean.util;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Service;

@Service
public class TranslateService {

	static int responseCode = 0;

	// source : 변환할 언어, target : 변환될 언어, text : 변환 할 문장
	public String Translate(String source, String target, String text) {

		String clientId = "tIPF1_HnczgpFPE3xjR5";// 애플리케이션 클라이언트 아이디값";
		String clientSecret = "DxTNJCQT4t";// 애플리케이션 클라이언트 시크릿값";
		String apiURL = "https://openapi.naver.com/v1/papago/n2mt"; // API 서버주소

		try {
			text = URLEncoder.encode(text, "UTF-8"); // 변환할 문장을 UTF-8로 인코딩 합니다.
			Map<String, String> requestHeaders = new HashMap<>();
			requestHeaders.put("X-Naver-Client-Id", clientId);
			requestHeaders.put("X-Naver-Client-Secret", clientSecret);

			String responseBody = post(apiURL, requestHeaders, source, target, text);

			// System.out.println("responseBody=" + responseBody);
			// System.out.println(responseCode);
			if (responseCode == 200) {
				// JSON 형식으로 출력된 결과값을 파싱하는 과정!
				JSONParser parser = new JSONParser();
				Object ob = (JSONObject) parser.parse(responseBody.toString());
				JSONObject jsonObj = (JSONObject) ob;

				Object obje = jsonObj.get("message");
				JSONObject jsonObj2 = (JSONObject) obje;

				// System.out.println("res1=" + jsonObj2);
				Object obj = (Object) jsonObj2.get("result");
				JSONObject jsonObj3 = (JSONObject) obj;

				// System.out.println("res2=" + jsonObj3);
				String res = (String) jsonObj3.get("translatedText");
				System.out.println(res);

				return res;

			} else {

				return "번역 전 후 언어를 다르게 설정해주세요.";

			}

		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException("인코딩 실패", e);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;

	}

	private static String post(String apiUrl, Map<String, String> requestHeaders, String source, String target,
			String text) {

		HttpURLConnection con = connect(apiUrl);
		// 파파고 API 서버로 전달할 파라미터를 설정
		String postParams = "source=" + source + "&target=" + target + "&text=" + text;
		try {
			con.setRequestMethod("POST");
			for (Map.Entry<String, String> header : requestHeaders.entrySet()) {
				con.setRequestProperty(header.getKey(), header.getValue());
			}

			// 파파고 API 서버로 번역할 문장을 전송합니다.
			con.setDoOutput(true);
			try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {
				wr.write(postParams.getBytes());
				wr.flush();
				wr.close();
			}

			// 파파고 API 서버로부터 번역된 메세지를 전달 받습니다.
			responseCode = con.getResponseCode();
			System.out.println("responseCode: " + responseCode);
			if (responseCode == HttpURLConnection.HTTP_OK) { // 정상 응답 200
				return readBody(con.getInputStream());
			} else { // 에러 응답
				return readBody(con.getErrorStream());
			}
		} catch (IOException e) {
			throw new RuntimeException("API 요청과 응답 실패", e);
		} finally {
			con.disconnect();
		}
	}

	// 파파고 API 서버와 연결하는 메소드
	private static HttpURLConnection connect(String apiUrl) {
		try {
			URL url = new URL(apiUrl);
			return (HttpURLConnection) url.openConnection();
		} catch (MalformedURLException e) {
			throw new RuntimeException("API URL이 잘못되었습니다. : " + apiUrl, e);
		} catch (IOException e) {
			throw new RuntimeException("연결이 실패했습니다. : " + apiUrl, e);
		}
	}

	private static String readBody(InputStream body) {
		InputStreamReader streamReader = new InputStreamReader(body);

		try (BufferedReader lineReader = new BufferedReader(streamReader)) {
			StringBuilder responseBody = new StringBuilder();

			// 전달하는 메세지를 출력합니다.
			String line;
			while ((line = lineReader.readLine()) != null) {
				responseBody.append(line);
			}

			lineReader.close();

			return responseBody.toString();
		} catch (IOException e) {
			throw new RuntimeException("API 응답을 읽는데 실패했습니다.", e);
		}
	}

}
