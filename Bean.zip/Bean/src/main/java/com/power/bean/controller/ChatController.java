package com.power.bean.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ChatController {
	
	
	
}
